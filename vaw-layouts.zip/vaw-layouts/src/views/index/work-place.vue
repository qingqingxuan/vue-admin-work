<template>
  <el-card>
    <div>this is work place</div>
  </el-card>
</template>

<script>
export default {
  name: 'WorkPlace'
}
</script>

<style>
</style>
