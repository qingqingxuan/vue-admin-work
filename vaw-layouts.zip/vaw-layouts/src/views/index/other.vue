<template>
  <RouterViewLayout />
</template>

<script>
import RouterViewLayout from '@/components/RouterViewLayout'
export default {
  name: 'Other',
  components: { RouterViewLayout }
}
</script>

<style>
</style>
