<template>
  <el-card>
    所有的订单
  </el-card>
</template>

<script>
export default {
  name: 'AllOrder'
}
</script>
