<template>
  <el-card>
    已支付成功的订单
  </el-card>
</template>

<script>
export default {
  name: 'PaySuccess'
}
</script>
