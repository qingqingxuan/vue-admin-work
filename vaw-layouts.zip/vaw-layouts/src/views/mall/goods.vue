<template>
  <el-card>
    商品管理
  </el-card>
</template>

<script>
export default {
  name: 'Goods'
}
</script>

<style>
</style>
